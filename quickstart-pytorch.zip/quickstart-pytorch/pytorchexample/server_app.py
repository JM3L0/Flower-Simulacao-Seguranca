"""pytorchexample: A Flower / PyTorch app."""

import torch
from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord
from flwr.serverapp import Grid, ServerApp
from flwr.serverapp.strategy import FedAvg, MultiKrum

from pytorchexample.task import Net, load_centralized_dataset, test

# Create ServerApp
app = ServerApp()


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main entry point for the ServerApp."""

    # Read run config
    fraction_evaluate: float = context.run_config["fraction-evaluate"]
    num_rounds: int = context.run_config["num-server-rounds"]
    lr: float = context.run_config["learning-rate"]

    # Load global model
    global_model = Net()
    arrays = ArrayRecord(global_model.state_dict())

    # Initialize FedAvg strategy
    # strategy = FedAvg(fraction_evaluate=fraction_evaluate)
    
    strategy = MultiKrum(
        num_malicious_nodes=2, 
        num_nodes_to_select=8, 
        fraction_evaluate=fraction_evaluate
    )  # Para a simulacao de ataques

    # Start strategy, run FedAvg for `num_rounds`
    result = strategy.start(
        grid=grid,
        initial_arrays=arrays,
        train_config=ConfigRecord({"lr": lr}),
        num_rounds=num_rounds,
        evaluate_fn=global_evaluate,
    )

    # Save final model to disk
    print("\nSaving final model to disk...")
    state_dict = result.arrays.to_torch_state_dict()
    torch.save(state_dict, "final_model.pt")

    # Export results to CSV (Excel)
    import pandas as pd
    print("\nExportando tabela de métricas para Excel (CSV)...")
    rodadas = []
    precisoes = []
    perdas = []
    for rodada, metricas in result.evaluate_metrics_serverapp.items():
        rodadas.append(rodada)
        precisoes.append(metricas["accuracy"])
        perdas.append(metricas["loss"])
        
    df = pd.DataFrame({
        "Rodada": rodadas,
        "Precisao Global": precisoes,
        "Perda Global": perdas
    })
    
    df.to_csv("tabela_resultados.csv", sep=";", index=False, decimal=",")
    print("Sucesso! Arquivo 'tabela_resultados.csv' criado na pasta do projeto.")


def global_evaluate(server_round: int, arrays: ArrayRecord) -> MetricRecord:
    """Evaluate model on central data."""

    # Load the model and initialize it with the received weights
    model = Net()
    model.load_state_dict(arrays.to_torch_state_dict())
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)

    # Load entire test set
    test_dataloader = load_centralized_dataset()

    # Evaluate the global model on the test set
    test_loss, test_acc = test(model, test_dataloader, device)

    # Return the evaluation metrics
    return MetricRecord({"accuracy": test_acc, "loss": test_loss})
